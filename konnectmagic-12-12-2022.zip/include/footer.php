 <!-- Start Footer Section -->
        <section class="footer-section ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="footer-area">
                            <div class="footer-heading">
                                <h3><img src="assets/img/logo-footer.png" class="black-logo" alt="image"></h3>
                            </div>

                            <p>5X Your LinkedIn Connections and Generate 40-50 More Conversations Per Week Automatically, also Increase the Effectiveness of Your LinkedIn Campaigns. </p>
                            <ul class="footer-social">
                                <li>
                                    <a href="#" class="bg-3955bc">
                                        <i class="flaticon-facebook-logo"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="bg-0273af">
                                        <i class="flaticon-linkedin-letters"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                        <div class="col-lg-1 col-md-6 col-sm-6">
                        </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-item-area">
                            <div class="footer-heading">
                                <h3>Important Links</h3>
                            </div>

                            <ul class="footer-quick-links">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="services.php">Services</a></li>
                                <li><a href="blog.php">Blog</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </div>    
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="footer-heading">
                            <h3>Contact</h3>
                        </div>

                        <div class="footer-info-contact">
                            <i class="flaticon-call-answer"></i>
                            <h3>Phone</h3>
                            <span>+91 637 874 0904</span>
                        </div>

                        <div class="footer-info-contact">
                            <i class="flaticon-envelope"></i>
                            <h3>Email</h3>
                            <span><a href="#"><span class="__cf_email__" data-cfemail="">info@konnectmagic.com</span></a></span>
                        </div>

                        
                    </div>
                </div>
            </div>

            <div class="default-animation">
                <div class="shape-img1"><img src="assets/img/shape/12.svg" alt="image"></div>
                <div class="shape-img2"><img src="assets/img/shape/13.svg" alt="image"></div>
                <div class="shape-img3"><img src="assets/img/shape/14.png" alt="image"></div>
                <div class="shape-img4"><img src="assets/img/shape/15.png" alt="image"></div>
                <div class="shape-img5"><img src="assets/img/shape/2.png" alt="image"></div>
            </div> 
        </section> 
        <!-- End Footer Section -->

        <!-- Start Copy Right Section -->
        <div class="copyright-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12 col-md-6">
                        <p>
                            Copyright @ Task Robots. All Rights Reserved.
                        </p>
                    </div>

                   
                </div>
            </div>
        </div>
        <!-- End Copy Right Section -->

        <!-- Start Go Top Section -->
        <div class="go-top">
            <i class="fas fa-chevron-up"></i>
            <i class="fas fa-chevron-up"></i>
        </div>
        <!-- End Go Top Section -->

        <!-- jQuery Min JS -->
        <script src="assets/js/jquery.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- MeanMenu JS  -->
        <script src="assets/js/jquery.meanmenu.js"></script>
        <!-- Appear Min JS -->
        <script src="assets/js/jquery.appear.min.js"></script>
        <!-- Odometer Min JS -->
        <script src="assets/js/odometer.min.js"></script>
        <!-- Owl Carousel Min JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- Magnific Popup Min JS -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Nice Select Min JS -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!-- Mixitup Min JS -->
        <script src="assets/js/jquery.mixitup.min.js"></script>
        <!-- WOW Min JS -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Parallax Min JS -->
        <script src="assets/js/parallax.min.js"></script>
        <!-- Ajaxchimp JS --> 
		<script src="assets/js/jquery.ajaxchimp.min.js"></script>
		<!-- Form Validator JS -->
		<script src="assets/js/form-validator.min.js"></script>
		<!-- Contact JS -->
		<script src="assets/js/contact-form-script.js"></script>
        <!-- Main JS -->
        <script src="assets/js/main.js"></script>
    </body>
</html>