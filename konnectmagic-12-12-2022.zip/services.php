<?php include 'include/header.php';?>

        <!-- Start Page Title Area -->
        <div class="page-title-area">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="page-title-content">
                            <h2>Services</h2>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li>Services</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page Title Area -->

     <!-- Start Features Area -->
        <section class="features-area">
            <div class="container">
                <div class="features-title">
                     <span>We Can Help!</span>
                    <h3>Robust and Reliable Desire Growth Is Difficult to Achieve!</h3>

                </div>

                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-features-item bg-b5a2f8">
                            <div class="icon">
                                <i class="flaticon-seo"></i>
                            </div>

                            <h3>LinkedIn Outbound Automation</h3>
                            <p>Our tool automates all the steps leading up to a chat. Now, instead of grinding to get a response, your reps can spend their time engaging in meaningful conversations with prospects.</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-features-item bg-f27e19">
                            <div class="icon">
                                <i class="flaticon-analytics"></i>
                            </div>

                            <h3>Content Marketing for SEO</h3>
                            <p>Our solution gives you the hard data, analytics, and recommendations you need to develop the correct content and subjects.</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-features-item bg-1db294">
                            <div class="icon">
                                <i class="flaticon-laptop"></i>
                            </div>

                            <h3>Effective ABM Campaigns</h3>
                            <p>Our tool assists you in mastering your ABM strategy and campaigns by assisting you in defining your ICP and identifying the techniques, data, tools, and resources.</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-features-item bg-e80d82">
                            <div class="icon">
                                <i class="flaticon-analysis-1"></i>
                            </div>

                            <h3>Sales and Marketing Operations</h3>
                            <p>We assist with organizations to ensure that all downstream functions are coordinated and optimized in order to capitalize on the increasing demand.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="features-animation">
                <div class="shape-img1"><img src="assets/img/shape/8.png" alt="image"></div>
                <div class="shape-img2"><img src="assets/img/shape/5.png" alt="image"></div>
            </div>
        </section>
        <!-- End Features Area -->
        <!-- Start Subscribe Section -->
        <section class="subscribe-section">
            <div class="container-fluid">
                <div class="subscribe-area-content">
                    <div class="subscribe-content">
                        <span class="sub-title">Get Started Instantly!</span>
                        <h2>Increase Lead Generation and Close Deals More Quickly</h2>

                        <form class="newsletter-form" data-toggle="validator">
                           <!--  <input type="email" class="form-control" placeholder="Your Email" name="EMAIL" required autocomplete="off"> -->

                            <button class="default-btn" type="submit">
                                Get Free Consultation 
                            </button>

                            <div id="validator-newsletter" class="form-result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Subscribe Section -->



   <?php include 'include/footer.php';?>