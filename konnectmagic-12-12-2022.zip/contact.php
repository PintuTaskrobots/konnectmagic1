<?php include 'include/header.php';?>
<?php   
if(!empty($_POST['send'])) {
 $userName = $_POST["userName"];
 $userEmail = $_POST["userEmail"];
 $userPhone = $_POST["userPhone"];
 $userCompany = $_POST["userCompany"];
 $Message = $_POST["Message"];
 $toEmail = "pintutaskrobots@gmail.com";

 $mailHeaders = "Name: " . $userName .
 "\r\n Email: " . $userEmail .
 "\r\n Phone: " . $userPhone .
 "\r\n Company: " . $userCompany .
 "\r\n Message: " . $Message . "\r\n"; 
 
 if(mail($toEmail, $userName, $mailHeaders)){
    $messages = "Your mail has been sent successfuly ! ";
    
 }  

}
 
?>
        <!-- Start Page Title Area -->
        <div class="page-title-area">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="page-title-content">
                            <h2>Contact</h2>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li>Contact</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page Title Area -->

        <!-- Start Contact Area -->
        <section class="contact-area ptb-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <div class="contact-box">
                            <div class="icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            
                            <div class="content">
                                <h4>Phone / Fax</h4>
                                <p><a href="#">(+91) 637 874 0904</a></p>
                               
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-12">
                        <div class="contact-box">
                            <div class="icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            
                            <div class="content">
                                <h4>E-mail</h4>
                                <p><a href="#"><span>info@konnectmagic.com</span> </a></p>
                               
                            </div>
                        </div>
                    </div>
                    
                   <!-- <div class="col-lg-4 col-md-12">
                        <div class="contact-box">
                            <div class="icon">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            
                            <div class="content">
                                <h4>Location</h4>
                                <p>2750 Quadra Street , Park Area, <span>Victoria, Canada.</span></p>
                            </div>
                        </div>
                    </div>-->
                    
                    <div class="col-lg-6">
                        <div class="contact-text">
                            <h3>Together, let's do this.</h3>
                            <p>Give us a call with your requirements, and we'll get back to you with a time to meet and collect any additional information we require to create a unique system that solves your demand generation requirements.</p>

                            <ul class="social-links">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                
                                <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <form method="post" action="" class="contactForm">
                            <div class="row">
                                <div class="col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" name="userName" id="name" class="form-control" required data-error="Please enter your name" placeholder="Your Name">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
    
                                <div class="col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="email" name="userEmail" id="email" class="form-control" required data-error="Please enter your email" placeholder="Your Email">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
    
                                <div class="col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" name="userPhone" id="phone_number" required data-error="Please enter your number" class="form-control" placeholder="Your Phone">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
    
                                <div class="col-lg-6 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" name="userCompany" id="msg_subject" class="form-control" required data-error="Please enter your Company" placeholder="Your Company">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
    
                                <div class="col-lg-12 col-md-12">
                                    <div class="form-group">
                                        <textarea name="Message" class="form-control textarea-hight" id="message" cols="30" rows="5" required data-error="Write your message" placeholder="Your Message"></textarea>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div> 
    
                                <div class="col-lg-12 col-md-12">
                                    <input type="submit" name="send" class="send-btn-one" value="Send Message">
                                        <?php if(!empty($messages)){?>
                            <div class="success">
                              <strong style="color:green;"> <?php echo $messages; ?> </strong>
                            </div>
                            <?php } ?>
                                    <div id="msgSubmit" class="h3 text-center hidden"></div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- Start Contact Area -->

            <!-- Start Subscribe Section -->
        <section class="subscribe-section">
            <div class="container-fluid">
                <div class="subscribe-area-content">
                    <div class="subscribe-content">
                        <span class="sub-title">Get Started Instantly!</span>
                        <h2>Increase Lead Generation and Close Deals More Quickly</h2>

                        <form class="newsletter-form" data-toggle="validator">
                           <!--  <input type="email" class="form-control" placeholder="Your Email" name="EMAIL" required autocomplete="off"> -->

                            <button class="default-btn" type="submit">
                                Get Free Consultation 
                            </button>

                            <div id="validator-newsletter" class="form-result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Subscribe Section -->
        
<?php include 'include/footer.php';?>