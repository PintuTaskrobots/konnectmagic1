<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
//include('connection.php');

require 'vendor/autoload.php';

$mail = new PHPMailer;
if (isset($_POST['action']) && $_POST['action'] == 'Connections_submit') {

    // print_r($_POST);
    // die;
    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $company = $_POST['company'];
    $description = $_POST['Message'];

    $message = '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Email </title>
        
    </head>
    
    <body style="padding: 0; margin:0">
    <div class="email-section">
    <table width="600px" border="0" cellpadding="0" cellspacing="0" style=" margin: 0 auto;    width: 600px;    border: 1px solid #ddd;">
        <tr>
            <td style="text-align: center; padding: 10px;background: #0B0320;"><a href="#"><img style="width: 120px;" src=""> </a></td>
        </tr>
        <tr> 
            <td style="padding:15px;line-height: 12px;font-family: system-ui;">
                <h3>Name :- ' . $name . ', </h3>
                <h3>Phone :- ' . $number . ', </h3>
                <h3>Email :- ' . $email . ', </h3>
                <h3>Company :- ' . $company . ', </h3>
                <h3>Description :- ' . $description . ', </h3>
                
                <h2>Thank you for registering with us </h2>
             </td>
        </tr>
    </table>
    </div>
     </body>
    </html>';

    $mail->isSMTP();
    $mail->SMTPDebug = 2;
    $mail->Mailer = "smtp";                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                     // Enable SMTP authentication
    $mail->Username = 'pintutaskrobots@gmail.com';          // SMTP username
    $mail->Password = 'euubjzfenkummtwm'; // SMTP password
    $mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                          // TCP port to connect to
    $mail->setFrom('pintutaskrobots@gmail.com', 'Konnectmagic');
    $mail->addReplyTo('pintutaskrobots@gmail.com', 'Konnectmagic');
    $mail->addAddress($email);   // Add a recipient

    $mail->isHTML(true);  // Set email format to HTML

    $bodyContent = $message;

    $mail->Subject = 'konnectmagic';
    $bodyContent = $message;
    $mail->Body = $bodyContent;

    $mail->Send();
}
