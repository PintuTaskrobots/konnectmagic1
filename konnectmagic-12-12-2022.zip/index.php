<?php include 'include/header.php'; ?>
<?php
// if (isset($_POST['send'])) {
//     $userName = $_POST["userName"];
//     $userEmail = $_POST["userEmail"];
//     $userPhone = $_POST["userPhone"];
//     $userCompany = $_POST["userCompany"];
//     $Message = $_POST["Message"];
//     $toEmail = "pintutaskrobots@gmail.com";

// $mailHeaders = "Name: " . $userName .
//     "\r\n Email: " . $userEmail .
//     "\r\n Phone: " . $userPhone .
//     "\r\n Company: " . $userCompany .
//     "\r\n Message: " . $Message . "\r\n";

// if (mail($toEmail, $userName, $mailHeaders)) {
//     $messages = "Your mail has been sent successfuly ! ";
// }
// }

?>
<!-- Start Home Banner Two -->
<div class="home-banner-two">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7 col-md-6">
                        <div class="main-banner-content">
                            <h1>Boost The Efficiency of Your LinkedIn Outreach</h1>
                            <p>5X Your LinkedIn Connections and Generate 40-50 More Conversations Per Week Automatically.</p>

                            <div class="banner-btn">
                                <a href="contact.php" class="default-btn-one">Free Consultation </a>

                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 col-md-6">
                        <div class="banner-form">
                            <div class="success">
                                <strong style="color:green;" id="status"></strong>
                            </div>
                            <form id="frmContact" action="" method="POST">
                                <div class="form-group">
                                    <!--<label>Name</label>-->
                                    <input type="text" name="userName" class="form-control" placeholder="Name" required="">
                                </div>

                                <div class="form-group">
                                    <!--<label>Email</label>-->
                                    <input type="text" name="userEmail" class="form-control" placeholder="Email" required="">
                                </div>
                                <div class="form-group">
                                    <!--	<label>Phone</label>-->
                                    <input type="text" name="userPhone" class="form-control" placeholder="Phone" required="">
                                </div>

                                <div class="form-group">
                                    <!--<label>Company </label>-->
                                    <input type="text" name="userCompany" class="form-control" placeholder="Company " required="">
                                </div>
                                <div class="form-group">
                                    <!--<label>Message </label>-->
                                    <textarea name="Message" class="form-control textarea-hight" id="message" cols="30" rows="5" required="" data-error="Write your message" placeholder="Your Message"></textarea>
                                </div>
                                <button type="submit" name="btn_submit" value="submit" class="btn btn-primary"> Register Now </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="banner-img-wrapper">
        <div class="banner-img-1">
            <img src="assets/img/left-shape.png" alt="image">
        </div>

        <div class="banner-img-2">
            <img src="assets/img/right-shape.png" alt="image">
        </div>
    </div>

    <div class="shape-img2"><img src="assets/img/shape/2.png" alt="image"></div>
    <div class="shape-img3"><img src="assets/img/shape/3.png" alt="image"></div>
    <div class="shape-img5"><img src="assets/img/shape/5.png" alt="image"></div>
    <div class="shape-img6"><img src="assets/img/shape/6.png" alt="image"></div>
    <div class="shape-img7"><img src="assets/img/shape/2.png" alt="image"></div>
    <div class="shape-img8"><img src="assets/img/shape/10.png" alt="image"></div>
    <div class="shape-img9"><img src="assets/img/shape/7.png" alt="image"></div>
    <div class="shape-img10"><img src="assets/img/shape/5.png" alt="image"></div>
    <div class="shape-img11"><img src="assets/img/shape/11.png" alt="image"></div>
</div>
<!-- End  Home Banner Two -->



<!-- Start Features Area -->
<section class="features-area">
    <div class="container">
        <div class="features-title">
            <span>We Can Help!</span>
            <h3>Robust and Reliable Desire Growth Is Difficult to Achieve!</h3>

        </div>

        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-features-item bg-b5a2f8">
                    <div class="icon">
                        <i class="flaticon-seo"></i>
                    </div>

                    <h3>LinkedIn Outbound Automation</h3>
                    <p>Our tool automates all the steps leading up to a chat. Now, instead of grinding to get a response, your reps can spend their time engaging in meaningful conversations with prospects.</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-features-item bg-f27e19">
                    <div class="icon">
                        <i class="flaticon-analytics"></i>
                    </div>

                    <h3>Content Marketing for SEO</h3>
                    <p>Our solution gives you the hard data, analytics, and recommendations you need to develop the correct content and subjects.</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-features-item bg-1db294">
                    <div class="icon">
                        <i class="flaticon-laptop"></i>
                    </div>

                    <h3>Effective ABM Campaigns</h3>
                    <p>Our tool assists you in mastering your ABM strategy and campaigns by assisting you in defining your ICP and identifying the techniques, data, tools, and resources.</p>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="single-features-item bg-e80d82">
                    <div class="icon">
                        <i class="flaticon-analysis-1"></i>
                    </div>

                    <h3>Sales and Marketing Operations</h3>
                    <p>We assist with organizations to ensure that all downstream functions are coordinated and optimized in order to capitalize on the increasing demand.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="features-animation">
        <div class="shape-img1"><img src="assets/img/shape/8.png" alt="image"></div>
        <div class="shape-img2"><img src="assets/img/shape/5.png" alt="image"></div>
    </div>
</section>
<!-- End Features Area -->

<!-- Start About Section -->
<!--  <section class="about-section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-12">
                        <div class="about-image">
                            <img src="assets/img/about-image.png" alt="image">
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12">
                        <div class="about-area-content">
                            <span>About Us</span>
                            <h3>We are Dynamic Team of Seo Agency</h3>
                            <strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt labore  dolore magna aliqua.</strong>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                        </div>

                        <div class="row">
                            <div class="col-lg-6 col-6 col-6">
                                <div class="single-fun-facts">
                                    <h3><span class="odometer" data-count="1165">00</span><span class="sign-icon">+</span></h3>
                                    <p>Project Completed</p>
                                </div>
                            </div>

                            <div class="col-lg-6 col-6 col-6">
                                <div class="single-fun-facts">
                                    <h3><span class="odometer" data-count="2665">00</span><span class="sign-icon">+</span></h3>
                                    <p>Satisfied Clients</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>  -->
<!-- End About Section -->

<!-- Start Choose Section -->
<section class="choose-section bg-fafafa">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12">
                <div class="choose-content-area">
                    <h3>Strategic LinkedIn Outreach</h3>
                    <p>It takes time to develop an effective LinkedIn approach. Today's decision makers require more than a simple "hello" to convert. Our tool focused outreach, combined with finest messaging, enables you to generate more leads and fill the queue more quickly. Our goal is to make LinkedIn automation available to anyone.</p>

                    <div class="choose-text">
                        <i class="flaticon-check-mark"></i>
                        <!-- <h4>First Working Process</h4> -->
                        <p>Our professionals are glad to handle LinkedIn outreach for a large number of satisfied clients.</p>
                    </div>



                    <div class="choose-btn">
                        <a href="contact.php" class="default-btn-one">Free Consultation</a>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 col-md-12">
                <div class="choose-image">
                    <img src="assets/img/choose-image.png" alt="image">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Choose Section -->



<!-- Start Choose Section -->
<section class="choose-section bg-fafafa">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12">
                <div class="choose-image">
                    <img src="assets/img/choose-image2.png" alt="image">
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="choose-content-area">

                    <h3>Explore New Market Opportunities</h3>
                    <p>We use high-quality data to create a tailored list of your ideal prospects, and we approach your most qualified decision makers to identify those possibilities.

                        Our data-driven methodology assists our clients in scheduling more meetings. We also help our clients with advanced demand generating techniques.
                    </p>




                    <div class="choose-btn">
                        <a href="contact.php" class="default-btn-one">Free Consultation</a>
                    </div>
                </div>
            </div>


        </div>
    </div>
</section>
<!-- End Choose Section -->

<!-- Start Choose Section -->
<section class="choose-section bg-fafafa">
    <div class="container">
        <div class="row align-items-center">

            <div class="col-lg-6 col-md-12">
                <div class="choose-content-area">

                    <h3>Grow More Rapidly Using Data-Driven Approaches</h3>
                    <p>We are a well-established staff with technical knowledge of LinkedIn. With over 5 years of experience in Demand Gen, we are your dependable digital ally. Our distinct informative strategy enables you to scale more quickly.</p>




                    <div class="choose-btn">
                        <a href="contact.php" class="default-btn-one">Free Consultation</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="choose-image">
                    <img src="assets/img/choose-image3.png" alt="image">
                </div>
            </div>


        </div>
    </div>
</section>
<!-- End Choose Section -->


<!-- Start Pricing Section -->
<section class="pricing-section ptb-100">
    <div class="container">
        <div class="section-title">
            <span>Pricing Plans</span>
            <h3>With Completely Automated Outreach, You Can Convert Cold Leads into Clients</h3>
        </div>

        <div class="tab pricing-tab">
            <ul class="tabs">
                <li>
                    <a href="#">Monthly</a>
                </li>

                <li>
                    <a href="#">Yearly</a>
                </li>
            </ul>

            <div class="tab-content">
                <div class="tabs-item">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="single-pricing-box bg-f6f5fb">
                                <div class="pricing-header">
                                    <h3>Basic Plan</h3>
                                </div>

                                <div class="price">
                                    <strong>$</strong>
                                    <span>24</span>
                                </div>

                                <ul class="pricing-features">
                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Audits
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Management
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Copywriting
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Link Building
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Site Migration
                                    </li>
                                </ul>

                                <div class="price-btn">
                                    <a href="#" class="price-btn-one">Get Started</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="single-pricing-box bg-ed0678">
                                <div class="pricing-header">
                                    <h3>Standard Plan</h3>
                                </div>

                                <div class="price">
                                    <strong>$</strong>
                                    <span>59</span>
                                </div>

                                <ul class="pricing-features">
                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Audits
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Management
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Copywriting
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Link Building
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Site Migration
                                    </li>
                                </ul>

                                <div class="price-btn">
                                    <a href="#" class="price-btn-one">Get Started</a>
                                </div>

                                <div class="pricing-shape">
                                    <img src="assets/img/pricing-shape.png" alt="image">
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3">
                            <div class="single-pricing-box bg-edfbf8">
                                <div class="pricing-header">
                                    <h3>Premium Plan</h3>
                                </div>

                                <div class="price">
                                    <strong>$</strong>
                                    <span>89</span>
                                </div>

                                <ul class="pricing-features">
                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Audits
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Management
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Copywriting
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Link Building
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Site Migration
                                    </li>
                                </ul>

                                <div class="price-btn">
                                    <a href="#" class="price-btn-one">Get Started</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tabs-item">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="single-pricing-box bg-f6f5fb">
                                <div class="pricing-header">
                                    <h3>Basic Plan</h3>
                                </div>

                                <div class="price">
                                    <strong>$</strong>
                                    <span>24</span>
                                </div>

                                <ul class="pricing-features">
                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Audits
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Management
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Copywriting
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Link Building
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Site Migration
                                    </li>
                                </ul>

                                <div class="price-btn">
                                    <a href="#" class="price-btn-one">Get Started</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="single-pricing-box bg-ed0678">
                                <div class="pricing-header">
                                    <h3>Standard Plan</h3>
                                </div>

                                <div class="price">
                                    <strong>$</strong>
                                    <span>59</span>
                                </div>

                                <ul class="pricing-features">
                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Audits
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Management
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Copywriting
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Link Building
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Site Migration
                                    </li>
                                </ul>

                                <div class="price-btn">
                                    <a href="#" class="price-btn-one">Get Started</a>
                                </div>

                                <div class="pricing-shape">
                                    <img src="assets/img/pricing-shape.png" alt="image">
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3">
                            <div class="single-pricing-box bg-edfbf8">
                                <div class="pricing-header">
                                    <h3>Premium Plan</h3>
                                </div>

                                <div class="price">
                                    <strong>$</strong>
                                    <span>89</span>
                                </div>

                                <ul class="pricing-features">
                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Audits
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Management
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        SEO Copywriting
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Link Building
                                    </li>

                                    <li>
                                        <i class='flaticon-check-mark'></i>
                                        Site Migration
                                    </li>
                                </ul>

                                <div class="price-btn">
                                    <a href="#" class="price-btn-one">Get Started</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Pricing Section -->

<!-- Start Choose Section -->
<section class="choose-section bg-fafafa">
    <div class="container">
        <div class="row align-items-center">

            <div class="col-lg-6 col-md-12">
                <div class="choose-content-area">

                    <h3>Increase the Effectiveness of Your LinkedIn Campaign</h3>
                    <p>When you stop advertising, you leave a void that other businesses quickly fill. We make certain that you make the most of it and stand out from the crowd by using the appropriate messaging..</p>




                    <div class="choose-btn">
                        <a href="contact.php" class="default-btn-one">Free Consultation</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="choose-image">
                    <img src="assets/img/choose-image4.png" alt="image">
                </div>
            </div>


        </div>
    </div>
</section>
<!-- End Choose Section -->


<!-- Start Blog Section -->
<section class="blog-section pt-100">
    <div class="container">
        <div class="section-title">
            <span>Blog</span>
            <h3>Read Our Latest Blogs</h3>
        </div>

        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="blog-item">
                    <div class="blog-image">
                        <a href="the-advantages-of-using-linkedIn-automation-tools.php">
                            <img src="assets/img/blog1.jpg" alt="image">
                        </a>
                    </div>

                    <div class="single-blog-item">


                        <div class="blog-content">
                            <a href="the-advantages-of-using-linkedIn-automation-tools.php">
                                <h3>The Advantages of Using LinkedIn Automation Tools</h3>
                            </a>
                            <p>LinkedIn Automation is an excellent way to create leads, interact with industry leaders, and reach your target audience while saving time and money.</p>
                        </div>

                        <div class="blog-btn">
                            <a href="the-advantages-of-using-linkedIn-automation-tools.php" class="blog-btn-one">Read More</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="blog-item">
                    <div class="blog-image">
                        <a href="linkedIn-automation-tool-lead-generation-tips.php">
                            <img src="assets/img/blog2.jpg" alt="image">
                        </a>
                    </div>

                    <div class="single-blog-item">


                        <div class="blog-content">
                            <a href="linkedIn-automation-tool-lead-generation-tips.php">
                                <h3>LinkedIn Automation Tool Lead Generation Tips</h3>
                            </a>
                            <p>Many marketers use Facebook, Instagram, and Twitter to generate leads. They could be losing out: LinkedIn offers its users a one-of-a-kind professional network.</p>
                        </div>

                        <div class="blog-btn">
                            <a href="linkedIn-automation-tool-lead-generation-tips.php" class="blog-btn-one">Read More</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 offset-lg-0 offset-md-3">
                <div class="blog-item">
                    <div class="blog-image">
                        <a href="how-can-linkedIn-automation-help-recruiters.php">
                            <img src="assets/img/blog3.jpg" alt="image">
                        </a>
                    </div>

                    <div class="single-blog-item">


                        <div class="blog-content">
                            <a href="how-can-linkedIn-automation-help-recruiters.php">
                                <h3>How Can LinkedIn Automation Help Recruiters?</h3>
                            </a>
                            <p>Using technologies to automate some of your LinkedIn management activities can free your time to focus on more important and personal aspects of your recruitment firm. </p>
                        </div>

                        <div class="blog-btn">
                            <a href="how-can-linkedIn-automation-help-recruiters.php" class="blog-btn-one">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Blog Section -->

<!-- Start Subscribe Section -->
<section class="subscribe-section">
    <div class="container-fluid">
        <div class="subscribe-area-content">
            <div class="subscribe-content">
                <span class="sub-title">Get Started Instantly!</span>
                <h2>Increase Lead Generation and Close Deals More Quickly</h2>

                <form class="newsletter-form" data-toggle="validator">
                    <!--  <input type="email" class="form-control" placeholder="Your Email" name="EMAIL" required autocomplete="off"> -->

                    <button class="default-btn" type="submit">
                        Get Free Consultation
                    </button>

                    <div id="validator-newsletter" class="form-result"></div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- End Subscribe Section -->

<?php include 'include/footer.php'; ?>

<script>
    $(document).ready(function(e) {
        $("#frmContact").on('submit', (function(e) {
            e.preventDefault();
            $.ajax({
                url: "home_ajax.php",
                type: "POST",
                data: {
                    "name": $('input[name="userName"]').val(),
                    "email": $('input[name="userEmail"]').val(),
                    "number": $('input[name="userPhone"]').val(),
                    "company": $('input[name="userCompany"]').val(),
                    "Message": $('textarea[name="Message"]').val(),
                    "action": "Connections_submit"
                },
                success: function(response) {
                    console.log('hi');
                    $('#frmContact')[0].reset();
                    $("#status").html('Your mail has been sent successfuly !!');
                },
            });
        }));
    });
</script>