<?php include 'include/header.php';?>



        <!-- Start Page Title Area -->
        <div class="page-title-area">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="page-title-content">
                            <h2>Blog</h2>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li>Blog</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page Title Area -->

        <!-- Start Blog Page Area -->
        <section class="blog-page-area ptb-100">
            <div class="container">
                 <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="blog-item">
                            <div class="blog-image">
                                <a href="the-advantages-of-using-linkedIn-automation-tools.php">
                                    <img src="assets/img/blog1.jpg" alt="image">
                                </a>
                            </div>

                            <div class="single-blog-item">
                                

                                <div class="blog-content">
                                    <a href="the-advantages-of-using-linkedIn-automation-tools.php">
                                        <h3>The Advantages of Using LinkedIn Automation Tools</h3>
                                    </a>
                                    <p>LinkedIn Automation is an excellent way to create leads, interact with industry leaders, and reach your target audience while saving time and money.</p>
                                </div>

                                <div class="blog-btn">
                                    <a href="the-advantages-of-using-linkedIn-automation-tools.php" class="blog-btn-one">Read More</a>
                                </div>
                            </div>  
                        </div>  
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="blog-item">
                            <div class="blog-image">
                                <a href="linkedIn-automation-tool-lead-generation-tips.php">
                                    <img src="assets/img/blog2.jpg" alt="image">
                                </a>
                            </div>

                            <div class="single-blog-item">
                                

                                <div class="blog-content">
                                    <a href="linkedIn-automation-tool-lead-generation-tips.php">
                                        <h3>LinkedIn Automation Tool Lead Generation Tips</h3>
                                    </a>
                                    <p>Many marketers use Facebook, Instagram, and Twitter to generate leads. They could be losing out: LinkedIn offers its users a one-of-a-kind professional network.</p>
                                </div>

                                <div class="blog-btn">
                                    <a href="linkedIn-automation-tool-lead-generation-tips.php" class="blog-btn-one">Read More</a>
                                </div>
                            </div>  
                        </div>  
                    </div>

                    <div class="col-lg-4 col-md-6 offset-lg-0 offset-md-3">
                        <div class="blog-item">
                            <div class="blog-image">
                                <a href="how-can-linkedIn-automation-help-recruiters.phpl">
                                    <img src="assets/img/blog3.jpg" alt="image">
                                </a>
                            </div>

                            <div class="single-blog-item">
                                

                                <div class="blog-content">
                                    <a href="how-can-linkedIn-automation-help-recruiters.php">
                                        <h3>How Can LinkedIn Automation Help Recruiters?</h3>
                                    </a>
                                    <p>Using technologies to automate some of your LinkedIn management activities can free your time to focus on more important and personal aspects of your recruitment firm. </p>
                                </div>

                                <div class="blog-btn">
                                    <a href="how-can-linkedIn-automation-help-recruiters.php" class="blog-btn-one">Read More</a>
                                </div>
                            </div>  
                        </div>  
                    </div>
                </div>
            </div>
        </section>
        <!-- End Blog Page Area -->

<?php include 'include/footer.php';?>